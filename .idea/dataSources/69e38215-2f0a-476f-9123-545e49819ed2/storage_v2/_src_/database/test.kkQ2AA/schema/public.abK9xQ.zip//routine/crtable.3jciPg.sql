create function crtable()
  returns void
language plpgsql
as $$
BEGIN
	CREATE TABLE IF NOT EXISTS mytable
	(
		id SERIAL PRIMARY KEY,
		FirstName CHARACTER VARYING(30),
		LastName CHARACTER VARYING(30)
	);
END;
$$;

