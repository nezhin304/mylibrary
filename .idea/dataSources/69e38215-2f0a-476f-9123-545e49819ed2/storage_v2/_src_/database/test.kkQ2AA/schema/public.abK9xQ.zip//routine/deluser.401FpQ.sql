create function deluser(user_id integer)
  returns void
language plpgsql
as $$
BEGIN
	DELETE FROM mytable WHERE
	id = user_id;
END;
$$;

