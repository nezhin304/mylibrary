create function deluser(user_name character varying)
  returns void
language plpgsql
as $$
BEGIN
	DELETE FROM mytable WHERE
	firstname = user_name;
END;
$$;

